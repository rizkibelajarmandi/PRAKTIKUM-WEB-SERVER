<?php
// app/Models/Mahasiswa.php

class Mahasiswa {
    // Properti dibuat PRIVATE (Encapsulation)
    private $nim;
    private $nama;
    private $jurusan;

    // ================= GETTER & SETTER =================

    public function getNim() {
        return $this->nim;
    }

    public function setNim($nim) {
        if (empty($nim)) {
            throw new Exception("NIM tidak boleh kosong!");
        }
        $this->nim = $nim;
    }

    public function getNama() {
        return $this->nama;
    }

    public function setNama($nama) {
        if (empty($nama)) {
            throw new Exception("Nama tidak boleh kosong!");
        }
        $this->nama = $nama;
    }

    public function getJurusan() {
        return $this->jurusan;
    }

    public function setJurusan($jurusan) {
        $this->jurusan = empty($jurusan) ? '-' : $jurusan;
    }
}
?>