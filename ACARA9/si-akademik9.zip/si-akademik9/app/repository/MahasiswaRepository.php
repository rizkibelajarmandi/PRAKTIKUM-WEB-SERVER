<?php
// app/Repository/MahasiswaRepository.php

class MahasiswaRepository {
    private $pdo;

    // DEPENDENCY INJECTION: PDO dimasukkan lewat constructor
    public function __construct($pdo) {
        $this->pdo = $pdo;
    }

    // Mengambil semua data mahasiswa sebagai OBJEK Mahasiswa
    public function getAll() {
        $stmt = $this->pdo->query("SELECT * FROM mahasiswa ORDER BY nama ASC");
        return $stmt->fetchAll(PDO::FETCH_CLASS, 'Mahasiswa');
    }

    // Mengambil satu data mahasiswa berdasarkan NIM
    public function getByNim($nim) {
        $stmt = $this->pdo->prepare("SELECT * FROM mahasiswa WHERE nim = :nim");
        $stmt->execute(['nim' => $nim]);
        $stmt->setFetchMode(PDO::FETCH_CLASS, 'Mahasiswa');
        return $stmt->fetch();
    }

    // Menyimpan data mahasiswa baru (menerima OBJEK Mahasiswa)
    public function save($mahasiswa) {
        $stmt = $this->pdo->prepare("INSERT INTO mahasiswa (nim, nama, jurusan) VALUES (:nim, :nama, :jurusan)");
        return $stmt->execute([
            'nim'     => $mahasiswa->getNim(),
            'nama'    => $mahasiswa->getNama(),
            'jurusan' => $mahasiswa->getJurusan()
        ]);
    }

    // Mengupdate data mahasiswa
    public function update($mahasiswa) {
        $stmt = $this->pdo->prepare("UPDATE mahasiswa SET nama = :nama, jurusan = :jurusan WHERE nim = :nim");
        return $stmt->execute([
            'nim'     => $mahasiswa->getNim(),
            'nama'    => $mahasiswa->getNama(),
            'jurusan' => $mahasiswa->getJurusan()
        ]);
    }

    // Menghapus data mahasiswa
    public function delete($nim) {
        $stmt = $this->pdo->prepare("DELETE FROM mahasiswa WHERE nim = :nim");
        return $stmt->execute(['nim' => $nim]);
    }
}
?>