<?php
// app/Controllers/MahasiswaController.php

require_once __DIR__ . '/../Models/Mahasiswa.php';
require_once __DIR__ . '/../Repository/MahasiswaRepository.php';

class MahasiswaController
{
    // OBJECT COMPOSITION: Controller "memiliki" Repository
    private $repo;

    public function __construct(MahasiswaRepository $repo)
    {
        $this->repo = $repo;
    }

    public function index()
    {
        $mahasiswa = $this->repo->getAll();
        require_once __DIR__ . '/../Views/mahasiswa/index.php';
    }

    public function detail($nim)
    {
        $mahasiswa = $this->repo->getByNim($nim);
        if (!$mahasiswa) {
            http_response_code(404);
            echo "Mahasiswa tidak ditemukan";
            return;
        }
        require_once __DIR__ . '/../Views/mahasiswa/detail.php';
    }
}
?>